export interface SiteProfile {
  id: "rother" | "joseph";
  short: string;
  name: string;
  place: string;
  url: string;
  repo: string;
  tagline: string;
  overall: number;
  version: string;
  pages: number;
  images: number;
  tests: string;
  e2e: string;
  heroLine: string;
  role: string;
}

export interface Dimension {
  id: string;
  label: string;
  rother: number;
  joseph: number;
  note: string;
  winner: "rother" | "joseph" | "tie";
}

export interface Finding {
  id: string;
  severity: "Advantage" | "Gap" | "Shared";
  site: "Rother" | "St Joseph" | "Both";
  title: string;
  evidence: string;
  impact: string;
  confidence: "Verified" | "Reasoned" | "Assumed";
}

export const rother: SiteProfile = {
  id: "rother",
  short: "Rother",
  name: "Blessed Stanley Rother Shrine",
  place: "Oklahoma City",
  url: "https://rothershrine.jesspete.shop/",
  repo: "https://github.com/nordeim/rothershrine-v2",
  tagline: "The Shepherd Who Stayed",
  overall: 7.8,
  version: "1.3.0",
  pages: 10,
  images: 4,
  tests: "6 files / 29",
  e2e: "20",
  heroLine: "A national shrine for pilgrims, parish groups, and school tours.",
  role: "Original liturgical system",
};

export const joseph: SiteProfile = {
  id: "joseph",
  short: "St Joseph",
  name: "St Joseph's Church (Bukit Timah)",
  place: "Singapore",
  url: "https://st-joseph.jesspete.shop/",
  repo: "https://github.com/nordeim/st-joseph-bt",
  tagline: "A church on the hill since 1846",
  overall: 8.4,
  version: "1.0.0",
  pages: 10,
  images: 8,
  tests: "11 files / 67",
  e2e: "27",
  heroLine: "Singapore's second-oldest Catholic parish, ported from the shrine skin.",
  role: "Parish port + Sacred Motion",
};

export const dimensions: Dimension[] = [
  {
    id: "identity",
    label: "Visual identity",
    rother: 8.4,
    joseph: 7.2,
    winner: "rother",
    note: "Rother authored the maroon/cream/gold liturgical voice. St Joseph inherits it almost token-for-token, so the parish brand reads as a clone with local copy rather than a distinct visual language.",
  },
  {
    id: "type",
    label: "Typography",
    rother: 8.6,
    joseph: 8.6,
    winner: "tie",
    note: "Identical pairing: Fraunces for display, Source Sans 3 for body. Both set headings in shrine-maroon-700, use text-balance, and load via Google Fonts. Rother requests one extra Fraunces weight (800).",
  },
  {
    id: "color",
    label: "Color & texture",
    rother: 8.5,
    joseph: 8.5,
    winner: "tie",
    note: "Twenty-four shrine-* tokens and two shadows are byte-identical. Grain, adobe radial wash, gold-rule, and the gold/maroon/pine divider-weave appear on both. Material language is shared, not differentiated.",
  },
  {
    id: "motion",
    label: "Motion & delight",
    rother: 6.6,
    joseph: 8.8,
    winner: "joseph",
    note: "Both have Ken Burns (20s), scroll reveal, and gold-rule draw. St Joseph adds staged rise-in, menu-in, drawer-in, timeline halo-pulse, and accordion height animation — the Sacred Motion pass documented 2026-08-28.",
  },
  {
    id: "craft",
    label: "Interaction craft",
    rother: 6.9,
    joseph: 8.6,
    winner: "joseph",
    note: "Rother lifts some grounds cards and buttons; other cards stay static. St Joseph unifies hover via card-lift, gold link-underline, button press (active:scale 0.98), and row tints on Mass and PPC tables.",
  },
  {
    id: "ia",
    label: "Information architecture",
    rother: 8.0,
    joseph: 8.6,
    winner: "joseph",
    note: "Rother is a pilgrimage IA (What to See, Pilgrimage, Volunteer). St Joseph is a living-parish IA (Worship with #mass/#confession/#visit, Ministries jump nav, Serve) with more aliases and task density.",
  },
  {
    id: "nav",
    label: "Navigation",
    rother: 7.3,
    joseph: 8.7,
    winner: "joseph",
    note: "Shared: sticky maroon-950 header, hover+focus dropdowns, mobile drawer, skip link. St Joseph adds aria-current, 44px hamburger, drawer close on same-route taps, and a HashRouter-safe BackToTop.",
  },
  {
    id: "a11y",
    label: "Accessibility",
    rother: 7.2,
    joseph: 8.6,
    winner: "joseph",
    note: "Both: skip link, :focus-visible gold ring, global prefers-reduced-motion. St Joseph: 44px targets, aria-current on nav and ministry pills, inert closed accordion panels, larger jump pills.",
  },
  {
    id: "voice",
    label: "Voice & hierarchy",
    rother: 8.8,
    joseph: 8.4,
    winner: "rother",
    note: "Rother's martyrdom line is the stronger editorial hook. St Joseph's 'You are not a visitor here. You are expected.' is more intimate, and gold event chips improve scan hierarchy after the motion pass.",
  },
  {
    id: "imagery",
    label: "Photography",
    rother: 7.3,
    joseph: 8.3,
    winner: "joseph",
    note: "Rother ships 4 local images plus Pexels with 20% grayscale. St Joseph ships 8 locals, a Wikimedia hero, two Pexels CDNs, fetchPriority on LCP, and a PageHero fallback prop.",
  },
];

export const tokens = [
  { name: "cream", hex: "#faf6ec", use: "Page ground" },
  { name: "parchment", hex: "#f2e9d6", use: "Section bands" },
  { name: "ink", hex: "#2a2115", use: "Body text" },
  { name: "maroon-500", hex: "#7c2a25", use: "Links, eyebrows" },
  { name: "maroon-900", hex: "#33100f", use: "Hero / footer" },
  { name: "maroon-950", hex: "#200a0a", use: "Header strip" },
  { name: "gold-300", hex: "#e2bf72", use: "Dark eyebrows" },
  { name: "gold-500", hex: "#c3963f", use: "Primary button" },
  { name: "pine-500", hex: "#335840", use: "Accent / weave" },
  { name: "terracotta", hex: "#ab5f3c", use: "Community badge" },
];

export const motionRows = [
  {
    feature: "Hero Ken Burns (20s scale 1→1.05)",
    rother: true,
    joseph: true,
  },
  {
    feature: "Scroll reveal (translateY 24px, 700ms)",
    rother: true,
    joseph: true,
  },
  {
    feature: "Gold-rule draw-in",
    rother: true,
    joseph: true,
  },
  {
    feature: "Staged hero rise-in (90–380ms stagger)",
    rother: false,
    joseph: true,
  },
  {
    feature: "Dropdown menu-in / drawer-in",
    rother: false,
    joseph: true,
  },
  {
    feature: "Accordion 0fr→1fr height",
    rother: true,
    joseph: true,
  },
  {
    feature: "card-lift + gold border tint",
    rother: false,
    joseph: true,
  },
  {
    feature: "link-underline draw",
    rother: false,
    joseph: true,
  },
  {
    feature: "Timeline halo-pulse",
    rother: false,
    joseph: true,
  },
  {
    feature: "Button press (scale 0.98)",
    rother: false,
    joseph: true,
  },
  {
    feature: "Back-to-top (scrollY > 480)",
    rother: false,
    joseph: true,
  },
  {
    feature: "prefers-reduced-motion gate",
    rother: true,
    joseph: true,
  },
];

export const navCompare = {
  rother: [
    "Home",
    "About → Rother / History / FAQ",
    "What to See → Pilgrim Center / Church / Tepeyac",
    "Pilgrimage",
    "News & Events",
    "Volunteer",
  ],
  joseph: [
    "Home",
    "About → Parish / History / FAQ",
    "Worship → Mass / Confession / Find Us",
    "Ministries → Liturgical / Formation / Pastoral",
    "News & Events",
    "Serve",
  ],
};

export const findings: Finding[] = [
  {
    id: "F-01",
    severity: "Shared",
    site: "Both",
    title: "Same design system, same bones",
    evidence:
      "src/index.css @theme blocks match: shrine-cream #faf6ec through shrine-terracotta-500, Fraunces + Source Sans 3, shadow-shrine, HashRouter SPA, PageHero, Emblem, SkipLink, 4-col Footer.",
    impact:
      "Any visual comparison is a comparison of a parent and a port, not of two independent identities.",
    confidence: "Verified",
  },
  {
    id: "F-02",
    severity: "Advantage",
    site: "Rother",
    title: "Stronger original voice",
    evidence:
      "Hero line 'The Shepherd Who Stayed'; custom crook+wheat SVG favicon; theme-color #200a0a; pilgrimage IA aimed at visitors who do not already belong.",
    impact:
      "First impression feels authored for a national shrine rather than reused for a parish.",
    confidence: "Reasoned",
  },
  {
    id: "F-03",
    severity: "Advantage",
    site: "St Joseph",
    title: "Sacred Motion package",
    evidence:
      "docs/ui-ux-remediation-plan-2026-08-28.md E1–E9: rise-in, menu-in, drawer-in, card-lift, link-underline, halo-pulse, BackToTop, 44px targets, aria-current. Present in live CSS.",
    impact:
      "The parish site feels finished. Hover, entrance, and long-page navigation are coherent instead of patchy.",
    confidence: "Verified",
  },
  {
    id: "F-04",
    severity: "Gap",
    site: "Rother",
    title: "Inconsistent card and link affordance",
    evidence:
      "Live CSS has group-hover:scale-105 and button lift, but no .card-lift or .link-underline utilities. Footer links are color-only.",
    impact:
      "Interactive surfaces do not share a single hover language; the UI feels slightly unfinished next to the port.",
    confidence: "Verified",
  },
  {
    id: "F-05",
    severity: "Gap",
    site: "Rother",
    title: "Touch and current-page gaps",
    evidence:
      "Hamburger is documented at 40×40 (<44px AA). No aria-current on active nav. No BackToTop on History / What to See / Pilgrimage.",
    impact:
      "Keyboard and mobile users get less orientation on a long shrine site.",
    confidence: "Reasoned",
  },
  {
    id: "F-06",
    severity: "Advantage",
    site: "St Joseph",
    title: "Parish-task IA",
    evidence:
      "Worship canonical for /mass-times, /hours-location, /visit. Ministries jump nav with six ids. Chinese name 圣若瑟堂, Cashew MRT, PayNow UEN in Give.",
    impact:
      "A Sunday visitor can find Mass, confession, and a map without hunting pilgrimage metaphors.",
    confidence: "Verified",
  },
  {
    id: "F-07",
    severity: "Advantage",
    site: "St Joseph",
    title: "Richer image set and LCP care",
    evidence:
      "8 public/images vs 4; Wikimedia hero; SafeImage fetchPriority; PageHero fallback prop; grayscale 0.15 vs 0.20.",
    impact:
      "Grounds, chapel, cemetery, and feast photography carry more of the place. Slightly less desaturated.",
    confidence: "Verified",
  },
  {
    id: "F-08",
    severity: "Gap",
    site: "St Joseph",
    title: "Identity is still the shrine's",
    evidence:
      "Identical maroon-950 header, gold primary buttons, pine weave, Emblem crook+wheat lineage, even the word shrine-* in the token names of a parish that is not a shrine.",
    impact:
      "Bukit Timah does not look like Bukit Timah. It looks like Oklahoma City with Singapore copy.",
    confidence: "Reasoned",
  },
  {
    id: "F-09",
    severity: "Advantage",
    site: "St Joseph",
    title: "Social and document head",
    evidence:
      "og:title and og:description present. Rother has a richer <title>, theme-color, and inline SVG favicon, but no Open Graph tags in the deployed head.",
    impact:
      "Joseph shares more cleanly; Rother brands the browser chrome more carefully.",
    confidence: "Verified",
  },
  {
    id: "F-10",
    severity: "Shared",
    site: "Both",
    title: "Static-host constraints handled well",
    evidence:
      "HashRouter, skip link that does not rewrite hash, SafeImage CDN fallback, CSP meta, singlefile build. Joseph Layout clears the hash-scroll timeout; Rother does not.",
    impact:
      "Deep links work on GitHub Pages / S3. Joseph is slightly safer against timer leaks.",
    confidence: "Verified",
  },
];

export const methodNotes = [
  "Live HTML/CSS of both production deploys inspected (single-file SPAs; DOM after hydration was not screenshot-captured in this environment).",
  "Full design tokens, motion utilities, and Button/Header/Layout contracts read from GitHub main.",
  "St Joseph UI/UX remediation plan (2026-08-28) used as a primary evidence source for the motion delta.",
  "Scores are reasoned from source + deployed CSS, not from a lab user study. Photography quality judged from asset counts and treatment, not from a visual regression suite.",
];

export const wins = {
  rother: dimensions.filter((d) => d.winner === "rother").length,
  joseph: dimensions.filter((d) => d.winner === "joseph").length,
  tie: dimensions.filter((d) => d.winner === "tie").length,
};

import { joseph, rother } from "@/data/audit";

const ROTHER_LIVE =
  "https://images.pexels.com/photos/16538707/pexels-photo-16538707.jpeg?auto=compress&cs=tinysrgb&w=1600";
const JOSEPH_LIVE = "https://st-joseph.jesspete.shop/images/hero-church.jpg";

export function Frames() {
  return (
    <section id="frames" className="border-t border-rule bg-ink text-paper">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <p className="font-display text-[11px] font-semibold tracking-[0.28em] text-gold uppercase">
          03 — First impression
        </p>
        <h2 className="mt-3 max-w-3xl font-display text-4xl font-bold tracking-tight sm:text-5xl">
          Same hero machine. Different ground.
        </h2>
        <p className="mt-5 max-w-2xl text-lg leading-relaxed text-paper/70">
          Full-bleed photograph, maroon wash, gold eyebrow, Fraunces headline,
          two CTAs. Rother is a pilgrimage arrival. Joseph is a parish welcome.
          The layout is a twin; the story is not.
        </p>

        <div className="mt-14 grid gap-8 lg:grid-cols-2">
          <BrowserFrame
            url={rother.url.replace("https://", "")}
            image={ROTHER_LIVE}
            fallback="/images/rother-frame.jpg"
            alt="Sunlit facade of the Blessed Stanley Rother Shrine in Oklahoma City"
            eyebrow="National Shrine · Oklahoma City"
            title={rother.tagline}
            facts={["Hours", "Mass", "Feast 28 July", "700 SE 89th"]}
            tone="rother"
          />
          <BrowserFrame
            url={joseph.url.replace("https://", "")}
            image={JOSEPH_LIVE}
            fallback="/images/joseph-frame.jpg"
            alt="White Palladian church on a tropical hill at Bukit Timah, Singapore"
            eyebrow="Parish on the hill · Singapore"
            title={joseph.tagline}
            facts={["Mass 7.30", "Cashew MRT", "Feast 1 May", "圣若瑟堂"]}
            tone="joseph"
          />
        </div>

        <div className="mt-16 grid gap-8 border-t border-paper/15 pt-12 lg:grid-cols-3">
          <Note
            title="Rother hero"
            body="Mythic register. A martyr who went back. Quick facts (hours, location, Mass, feast) sit under the fold as a pilgrim briefing. Grounds preview: Pilgrim Center, Shrine Church, Tepeyac Hill."
          />
          <Note
            title="Joseph hero"
            body="Domestic register. 'You are expected.' Facts are Sunday Mass, MRT, 1 May. Grounds preview: Main Church, Chapel, Rosary Garden. Rise-in staggers the eyebrow, H1, lede, and CTAs."
          />
          <Note
            title="Photography"
            body="Rother: 4 locals + Pexels, 20% grayscale. Joseph: 8 locals + Wikimedia hero + 2 Pexels, fetchPriority on LCP, PageHero fallback. Joseph simply shows more of the place."
          />
        </div>
      </div>
    </section>
  );
}

function BrowserFrame({
  url,
  image,
  fallback,
  alt,
  eyebrow,
  title,
  facts,
  tone,
}: {
  url: string;
  image: string;
  fallback: string;
  alt: string;
  eyebrow: string;
  title: string;
  facts: string[];
  tone: "rother" | "joseph";
}) {
  return (
    <figure className="overflow-hidden border border-paper/15">
      <div className="flex items-center gap-2 border-b border-paper/15 bg-paper/5 px-4 py-2.5">
        <span className="h-2 w-2 rounded-full bg-paper/25" />
        <span className="h-2 w-2 rounded-full bg-paper/25" />
        <span className="h-2 w-2 rounded-full bg-paper/25" />
        <span className="ml-3 truncate font-mono text-[10px] text-paper/50">{url}</span>
      </div>
      <div className="relative aspect-[16/10] overflow-hidden bg-rother-deep">
        <img
          src={image}
          alt={alt}
          className="h-full w-full object-cover opacity-80"
          onError={(event) => {
            const img = event.currentTarget;
            if (img.dataset.fallback === "1") return;
            img.dataset.fallback = "1";
            img.src = fallback;
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-black/20" />
        <figcaption className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
          <p
            className={`font-display text-[10px] tracking-[0.22em] uppercase ${
              tone === "rother" ? "text-gold" : "text-[#e2bf72]"
            }`}
          >
            {eyebrow}
          </p>
          <p className="mt-2 font-display text-2xl leading-tight font-bold sm:text-3xl">
            {title}
          </p>
          <ul className="mt-4 flex flex-wrap gap-2">
            {facts.map((f) => (
              <li
                key={f}
                className="border border-paper/25 px-2 py-1 font-mono text-[10px] tracking-wide uppercase"
              >
                {f}
              </li>
            ))}
          </ul>
        </figcaption>
      </div>
    </figure>
  );
}

function Note({ title, body }: { title: string; body: string }) {
  return (
    <div>
      <h3 className="font-display text-lg font-bold">{title}</h3>
      <p className="mt-3 text-[0.98rem] leading-relaxed text-paper/70">{body}</p>
    </div>
  );
}



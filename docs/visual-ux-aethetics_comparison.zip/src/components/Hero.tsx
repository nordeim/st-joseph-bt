import { joseph, rother, wins } from "@/data/audit";

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-24 sm:pt-28">
      <div className="absolute inset-0">
        <img
          src="/images/hero-audit.jpg"
          alt=""
          className="h-full w-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-paper via-paper/85 to-paper" />
        <div className="grain absolute inset-0" />
      </div>

      <div className="relative mx-auto max-w-7xl px-5 pb-16 sm:px-8 sm:pb-24">
        <p className="rise font-display text-[11px] font-semibold tracking-[0.32em] text-sienna uppercase">
          Visual &amp; UX audit · two liturgical SPAs
        </p>
        <h1 className="rise mt-5 max-w-5xl font-display text-[2.6rem] leading-[0.95] font-extrabold tracking-tight text-ink sm:text-6xl lg:text-7xl">
          Two skins.
          <br />
          <span className="text-ink-soft">One system.</span>
        </h1>
        <p className="rise mt-8 max-w-2xl text-lg leading-relaxed text-ink-soft sm:text-xl">
          St Joseph&apos;s Bukit Timah is a port of the Blessed Stanley Rother
          Shrine. The tokens, type, header, and weave are the same. The
          difference is craft: motion, affordance, parish IA, and how finished
          the skin feels on a Sunday morning.
        </p>

        <div className="mt-14 grid gap-px bg-rule sm:grid-cols-2">
          <SiteScore
            kicker="A · Original"
            site={rother.short}
            place={rother.place}
            score={rother.overall}
            tagline={rother.tagline}
            wins={wins.rother}
            tone="rother"
            href={rother.url}
          />
          <SiteScore
            kicker="B · Port"
            site={joseph.short}
            place={joseph.place}
            score={joseph.overall}
            tagline={joseph.tagline}
            wins={wins.joseph}
            tone="joseph"
            href={joseph.url}
          />
        </div>

        <dl className="mt-8 grid grid-cols-2 gap-6 border-t border-rule pt-8 sm:grid-cols-4">
          <Meta label="Dimensions" value="10" />
          <Meta label="Joseph wins" value={String(wins.joseph)} />
          <Meta label="Rother wins" value={String(wins.rother)} />
          <Meta label="Ties" value={String(wins.tie)} />
        </dl>
      </div>
    </section>
  );
}

function SiteScore({
  kicker,
  site,
  place,
  score,
  tagline,
  wins: winCount,
  tone,
  href,
}: {
  kicker: string;
  site: string;
  place: string;
  score: number;
  tagline: string;
  wins: number;
  tone: "rother" | "joseph";
  href: string;
}) {
  return (
    <article className="bg-paper px-6 py-8 sm:px-10 sm:py-10">
      <p
        className={`font-display text-[11px] tracking-[0.22em] uppercase ${
          tone === "rother" ? "text-rother" : "text-joseph"
        }`}
      >
        {kicker}
      </p>
      <div className="mt-4 flex items-end justify-between gap-4">
        <div>
          <h2 className="font-display text-3xl font-bold tracking-tight">{site}</h2>
          <p className="mt-1 text-sm text-ink-mute">{place}</p>
        </div>
        <p className="font-display text-6xl leading-none font-extrabold tracking-tighter">
          {score.toFixed(1)}
        </p>
      </div>
      <p className="mt-6 max-w-sm text-[1.05rem] text-ink-soft italic">{tagline}</p>
      <div className="mt-8 flex items-center justify-between gap-4">
        <span className="font-mono text-[11px] tracking-wide text-ink-mute uppercase">
          {winCount} dimension {winCount === 1 ? "win" : "wins"}
        </span>
        <a
          href={href}
          target="_blank"
          rel="noreferrer"
          className="font-display text-[11px] font-semibold tracking-[0.16em] text-ink uppercase underline decoration-rule underline-offset-4 hover:decoration-sienna"
        >
          Live site
        </a>
      </div>
    </article>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="font-display text-[10px] tracking-[0.22em] text-ink-mute uppercase">
        {label}
      </dt>
      <dd className="mt-1 font-display text-2xl font-bold">{value}</dd>
    </div>
  );
}

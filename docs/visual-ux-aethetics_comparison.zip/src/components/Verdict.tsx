import { joseph, rother } from "@/data/audit";
import { HeaderBlock } from "@/components/Scorecard";

export function Verdict() {
  return (
    <section id="verdict" className="border-t border-rule bg-ink text-paper">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <p className="font-display text-[11px] font-semibold tracking-[0.28em] text-gold uppercase">
          07 — Verdict
        </p>
        <h2 className="mt-3 max-w-4xl font-display text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
          Joseph is the better product.
          <span className="text-paper/45"> Rother is the better original.</span>
        </h2>
        <p className="mt-8 max-w-2xl text-lg leading-relaxed text-paper/70">
          If you score craft, accessibility, and task fit, the parish port wins
          8.4 to 7.8. If you score authorship — a visual language invented for a
          place — Oklahoma still holds the pen. The honest recommendation is
          not to pick a winner. It is to send the Sacred Motion pass back
          upstream, and to let Bukit Timah grow a skin that is not named
          shrine-*.
        </p>

        <div className="mt-16 grid gap-px bg-paper/15 lg:grid-cols-2">
          <article className="bg-ink p-8 sm:p-10">
            <p className="font-display text-[11px] tracking-[0.2em] text-rother uppercase">
              Choose Rother when
            </p>
            <ul className="mt-6 space-y-3 text-[1.02rem] leading-relaxed text-paper/80">
              <li>You need a pilgrimage narrative with a martyr at the center.</li>
              <li>You want the crook-and-wheat emblem in its native context.</li>
              <li>Visitor jobs are hours, tomb, Tepeyac, and a group booking.</li>
              <li>You can live with patchy hover language until the motion pass lands.</li>
            </ul>
            <a
              href={rother.url}
              className="mt-8 inline-block font-display text-[11px] tracking-[0.18em] text-gold uppercase underline underline-offset-4"
              target="_blank"
              rel="noreferrer"
            >
              rothershrine.jesspete.shop
            </a>
          </article>
          <article className="bg-ink p-8 sm:p-10">
            <p className="font-display text-[11px] tracking-[0.2em] text-[#7dba93] uppercase">
              Choose St Joseph when
            </p>
            <ul className="mt-6 space-y-3 text-[1.02rem] leading-relaxed text-paper/80">
              <li>You need Mass, confession, MRT, and a ministry on the first try.</li>
              <li>Motion, press, underline, and back-to-top should feel finished.</li>
              <li>44px targets and aria-current are non-negotiable.</li>
              <li>You accept that the parish still wears Oklahoma&apos;s clothes.</li>
            </ul>
            <a
              href={joseph.url}
              className="mt-8 inline-block font-display text-[11px] tracking-[0.18em] text-gold uppercase underline underline-offset-4"
              target="_blank"
              rel="noreferrer"
            >
              st-joseph.jesspete.shop
            </a>
          </article>
        </div>

        <blockquote className="mt-16 max-w-3xl border-l-2 border-gold pl-6 text-xl leading-relaxed text-paper/85 italic sm:text-2xl">
          The lineage is the story. One system, two congregations. The next
          design problem is not polish — it is letting the hill look like the
          hill.
        </blockquote>
      </div>
    </section>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-rule bg-paper">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 py-10 sm:flex-row sm:items-end sm:justify-between sm:px-8">
        <div>
          <p className="font-display text-[11px] tracking-[0.28em] text-sienna uppercase">
            Lineage 01
          </p>
          <p className="mt-2 max-w-md text-sm text-ink-soft">
            Independent visual / UX comparison. Not affiliated with the
            Archdiocese of Oklahoma City or the Archdiocese of Singapore.
          </p>
        </div>
        <div className="flex flex-wrap gap-5 font-display text-[11px] tracking-[0.14em] uppercase">
          <a href={rother.repo} className="text-ink-soft hover:text-ink" target="_blank" rel="noreferrer">
            Rother repo
          </a>
          <a href={joseph.repo} className="text-ink-soft hover:text-ink" target="_blank" rel="noreferrer">
            Joseph repo
          </a>
          <a href="#top" className="text-sienna">
            Back to top
          </a>
        </div>
      </div>
    </footer>
  );
}

export function MethodStrip() {
  return (
    <section className="border-t border-rule bg-paper-2/30">
      <div className="mx-auto max-w-7xl px-5 py-10 sm:px-8">
        <HeaderBlock
          kicker="Confidence"
          title="Reasoned, with verified bones."
          lede="Overall scores 7.8 vs 8.4 are arithmetic means of the ten dimensions. They are not a user-test ranking. Production CSS and GitHub main were read; hydrated pixel screenshots were not taken in this environment."
        />
      </div>
    </section>
  );
}

import { joseph, navCompare, rother } from "@/data/audit";
import { HeaderBlock } from "@/components/Scorecard";

export function Architecture() {
  return (
    <section id="ia" className="border-t border-rule bg-paper-2/50">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <HeaderBlock
          kicker="05 — Architecture"
          title="Pilgrim versus parishioner."
          lede="The chrome is identical. The jobs-to-be-done are not. Rother orients a visitor who may never come back. St Joseph orients a household that needs Mass times, a ministry, and a PayNow UEN."
        />

        <div className="grid gap-px bg-rule lg:grid-cols-2">
          <NavCard
            label="Rother · primaryNav"
            items={navCompare.rother}
            accent="rother"
            note="What to See is a three-site tour. Pilgrimage is hours, maps, group visits. Volunteer is service as hospitality to guests."
          />
          <NavCard
            label="St Joseph · primaryNav"
            items={navCompare.joseph}
            accent="joseph"
            note="Worship collapses Mass, confession, and Find Us. Ministries is a jump-nav of six living groups. Serve is taking a place in the household."
          />
        </div>

        <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <Stat k="Pages" a={String(rother.pages)} b={String(joseph.pages)} />
          <Stat k="Local images" a={String(rother.images)} b={String(joseph.images)} />
          <Stat k="Unit tests" a={rother.tests} b={joseph.tests} />
          <Stat k="Playwright" a={rother.e2e} b={joseph.e2e} />
        </div>

        <div className="mt-16 grid gap-10 lg:grid-cols-2">
          <div>
            <h3 className="font-display text-2xl font-bold">Accessibility delta</h3>
            <ul className="mt-5 space-y-3 text-[0.98rem] leading-relaxed text-ink-soft">
              <li>
                <strong className="text-ink">Skip link</strong> — both, hash-preserving.
              </li>
              <li>
                <strong className="text-ink">Focus</strong> — both, 2px gold-500 offset 3px.
              </li>
              <li>
                <strong className="text-ink">Hamburger</strong> — Rother 40px (documented);
                Joseph 44px (h-11 w-11).
              </li>
              <li>
                <strong className="text-ink">aria-current</strong> — Joseph on active
                top-level and dropdown parent; Rother undocumented.
              </li>
              <li>
                <strong className="text-ink">Back to top</strong> — Joseph only, 44px,
                appears after 480px, never rewrites the hash.
              </li>
              <li>
                <strong className="text-ink">Accordion</strong> — Joseph closed panels
                use inert + aria-hidden with 0fr→1fr; Rother live CSS also has
                grid-template-rows transition.
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-display text-2xl font-bold">Document head</h3>
            <ul className="mt-5 space-y-3 text-[0.98rem] leading-relaxed text-ink-soft">
              <li>
                <strong className="text-ink">Rother</strong> — rich title, theme-color
                #200a0a, inline SVG favicon (crook + wheat), broader img-src
                https:, no Open Graph.
              </li>
              <li>
                <strong className="text-ink">Joseph</strong> — og:title / og:description,
                Chinese name in data, tighter CSP (Pexels + Wikimedia only), no
                theme-color in the deployed head.
              </li>
              <li>
                Both ship a scoped CSP because vite-plugin-singlefile inlines
                JS/CSS (unsafe-inline). Host HSTS is out of artifact control.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

function NavCard({
  label,
  items,
  accent,
  note,
}: {
  label: string;
  items: string[];
  accent: "rother" | "joseph";
  note: string;
}) {
  return (
    <article className="bg-paper p-8 sm:p-10">
      <p
        className={`font-display text-[11px] tracking-[0.2em] uppercase ${
          accent === "rother" ? "text-rother" : "text-joseph"
        }`}
      >
        {label}
      </p>
      <ol className="mt-6 space-y-3">
        {items.map((item, i) => (
          <li key={item} className="flex gap-4 border-b border-rule/70 pb-3">
            <span className="font-mono text-[11px] text-ink-mute">
              {String(i + 1).padStart(2, "0")}
            </span>
            <span className="text-[0.98rem]">{item}</span>
          </li>
        ))}
      </ol>
      <p className="mt-6 text-sm leading-relaxed text-ink-soft">{note}</p>
    </article>
  );
}

function Stat({ k, a, b }: { k: string; a: string; b: string }) {
  return (
    <div className="border border-rule bg-paper p-5">
      <p className="font-display text-[10px] tracking-[0.2em] text-ink-mute uppercase">
        {k}
      </p>
      <p className="mt-3 font-display text-lg font-bold text-rother">{a}</p>
      <p className="font-display text-lg font-bold text-joseph">{b}</p>
    </div>
  );
}

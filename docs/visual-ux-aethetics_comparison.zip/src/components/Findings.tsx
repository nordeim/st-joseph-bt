import { findings, methodNotes } from "@/data/audit";
import { HeaderBlock } from "@/components/Scorecard";

const severityClass: Record<(typeof findings)[number]["severity"], string> = {
  Advantage: "text-joseph",
  Gap: "text-rother",
  Shared: "text-sienna",
};

export function Findings() {
  return (
    <section id="findings" className="border-t border-rule">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <HeaderBlock
          kicker="06 — Findings"
          title="What the code actually shows."
          lede="Ten findings, classified as Advantage, Gap, or Shared. Confidence is tagged: Verified means read in source or live CSS. Reasoned is inference from those artifacts. Nothing here is a user-test result."
        />

        <ol className="space-y-0">
          {findings.map((f) => (
            <li
              key={f.id}
              className="grid gap-6 border-t border-rule py-8 lg:grid-cols-12"
            >
              <div className="lg:col-span-3">
                <p className="font-mono text-[11px] text-ink-mute">{f.id}</p>
                <p
                  className={`mt-2 font-display text-[11px] tracking-[0.18em] font-semibold uppercase ${severityClass[f.severity]}`}
                >
                  {f.severity} · {f.site}
                </p>
                <p className="mt-3 font-display text-xl font-bold leading-tight">
                  {f.title}
                </p>
              </div>
              <div className="lg:col-span-5">
                <p className="font-display text-[10px] tracking-[0.2em] text-ink-mute uppercase">
                  Evidence
                </p>
                <p className="mt-2 text-[0.98rem] leading-relaxed text-ink-soft">
                  {f.evidence}
                </p>
              </div>
              <div className="lg:col-span-4">
                <p className="font-display text-[10px] tracking-[0.2em] text-ink-mute uppercase">
                  Impact
                </p>
                <p className="mt-2 text-[0.98rem] leading-relaxed text-ink-soft">
                  {f.impact}
                </p>
                <p className="mt-4 font-mono text-[10px] tracking-wide text-ink-mute uppercase">
                  Confidence · {f.confidence}
                </p>
              </div>
            </li>
          ))}
        </ol>

        <div className="mt-4 border-t border-rule pt-10">
          <h3 className="font-display text-lg font-bold">Verification ledger</h3>
          <ul className="mt-4 space-y-2 text-sm leading-relaxed text-ink-soft">
            {methodNotes.map((n) => (
              <li key={n} className="flex gap-3">
                <span className="mt-2 h-1 w-1 shrink-0 bg-sienna" />
                <span>{n}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

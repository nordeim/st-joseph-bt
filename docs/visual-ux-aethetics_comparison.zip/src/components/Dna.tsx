import { tokens } from "@/data/audit";
import { HeaderBlock } from "@/components/Scorecard";

export function Dna() {
  return (
    <section id="dna" className="border-t border-rule">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <HeaderBlock
          kicker="02 — Shared DNA"
          title="The shrine palette never left Oklahoma."
          lede="St Joseph did not restyle the parish. It renamed the copy. Twenty-four color tokens, two shadows, Fraunces, Source Sans 3, the gold/maroon/pine weave, and the crook-and-wheat emblem language are the same contract."
        />

        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <ul className="grid grid-cols-2 gap-3 sm:grid-cols-5">
              {tokens.map((t) => (
                <li key={t.name} className="border border-rule bg-paper">
                  <div className="h-16" style={{ background: t.hex }} />
                  <div className="px-3 py-3">
                    <p className="font-mono text-[10px] tracking-wide text-ink uppercase">
                      {t.name}
                    </p>
                    <p className="font-mono text-[10px] text-ink-mute">{t.hex}</p>
                    <p className="mt-1 text-xs text-ink-soft">{t.use}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <aside className="space-y-6 lg:col-span-5">
            <figure className="border border-rule bg-ink px-6 py-8 text-paper">
              <p className="font-display text-[11px] tracking-[0.22em] text-gold uppercase">
                Type specimen
              </p>
              <p className="mt-5 font-display text-4xl leading-none font-bold tracking-tight">
                Fraunces
              </p>
              <p className="mt-2 text-sm text-paper/70">Display · opsz 9–144 · maroon-700</p>
              <p className="mt-8 font-serif text-2xl italic">Source Sans 3 is the body.</p>
              <p className="mt-2 text-sm text-paper/70">
                Both sites load the pairing from Google Fonts and set h1–h4 in
                shrine-maroon-700. Kerning and liga are on.
              </p>
            </figure>

            <div className="border border-rule p-6">
              <p className="font-display text-[11px] tracking-[0.22em] text-sienna uppercase">
                Shared chrome
              </p>
              <ul className="mt-4 space-y-2 text-[0.98rem] text-ink-soft">
                <li>Fixed maroon-950 header, gold Give CTA, useScrolled(16)</li>
                <li>PageHero with grain overlay and Ken Burns image</li>
                <li>divider-weave-thin on the 4-column footer</li>
                <li>Skip link, gold :focus-visible, reduced-motion nuke</li>
                <li>HashRouter + file-backed src/data — no CMS</li>
              </ul>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

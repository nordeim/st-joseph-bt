import { motionRows } from "@/data/audit";
import { HeaderBlock } from "@/components/Scorecard";

export function Motion() {
  return (
    <section id="motion" className="border-t border-rule">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <HeaderBlock
          kicker="04 — Sacred Motion"
          title="The port outgrew the original."
          lede="Rother already had Ken Burns, scroll reveal, and a gold rule. St Joseph's 2026-08-28 pass added staged entrances, a card-lift system, link underlines, a timeline halo, press feedback, and back-to-top — all transform/opacity, all gated by prefers-reduced-motion."
        />

        <div className="overflow-x-auto">
          <table className="w-full min-w-[36rem] border-collapse text-left">
            <caption className="sr-only">
              Motion and micro-interaction comparison
            </caption>
            <thead>
              <tr className="border-y border-rule">
                <th className="py-4 pr-4 font-display text-[11px] tracking-[0.18em] font-semibold text-ink-mute uppercase">
                  Feature
                </th>
                <th className="w-28 py-4 text-center font-display text-[11px] tracking-[0.18em] font-semibold text-rother uppercase">
                  Rother
                </th>
                <th className="w-28 py-4 text-center font-display text-[11px] tracking-[0.18em] font-semibold text-joseph uppercase">
                  St Joseph
                </th>
              </tr>
            </thead>
            <tbody>
              {motionRows.map((row) => (
                <tr key={row.feature} className="border-b border-rule/80">
                  <td className="py-3.5 pr-4 text-[0.98rem]">{row.feature}</td>
                  <td className="py-3.5 text-center font-mono text-sm">
                    <Mark on={row.rother} />
                  </td>
                  <td className="py-3.5 text-center font-mono text-sm">
                    <Mark on={row.joseph} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-3">
          <Callout
            tone="rother"
            title="Rother still moves"
            body="Hero Ken Burns, reveal-on-scroll, gold-rule-draw, button hover lift, accordion grid-rows. The original is not inert — it is incomplete."
          />
          <Callout
            tone="joseph"
            title="Joseph is coherent"
            body="Every card, link, menu, and timeline tick shares one easing curve (cubic-bezier 0.22, 1, 0.36, 1) and a 200–700ms window."
          />
          <Callout
            tone="sienna"
            title="A11y contract kept"
            body="Global reduced-motion sets animation-duration to 0.01ms. Joseph also disables Ken Burns and the halo explicitly."
          />
        </div>
      </div>
    </section>
  );
}

function Mark({ on }: { on: boolean }) {
  return on ? (
    <span className="text-joseph" aria-label="Present">
      ●
    </span>
  ) : (
    <span className="text-rule" aria-label="Absent">
      ○
    </span>
  );
}

function Callout({
  tone,
  title,
  body,
}: {
  tone: "rother" | "joseph" | "sienna";
  title: string;
  body: string;
}) {
  const bar =
    tone === "rother" ? "bg-rother" : tone === "joseph" ? "bg-joseph" : "bg-sienna";
  return (
    <article className="border border-rule p-6">
      <div className={`mb-4 h-0.5 w-10 ${bar}`} />
      <h3 className="font-display text-lg font-bold">{title}</h3>
      <p className="mt-3 text-[0.98rem] leading-relaxed text-ink-soft">{body}</p>
    </article>
  );
}

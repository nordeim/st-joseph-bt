import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";

const links = [
  { href: "#scores", label: "Scores" },
  { href: "#dna", label: "System" },
  { href: "#frames", label: "Frames" },
  { href: "#motion", label: "Motion" },
  { href: "#ia", label: "IA" },
  { href: "#findings", label: "Findings" },
  { href: "#verdict", label: "Verdict" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const ids = links.map((l) => l.href.slice(1));
    const observers: IntersectionObserver[] = [];

    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) setActive(id);
          });
        },
        { rootMargin: "-40% 0px -50% 0px", threshold: 0 },
      );
      io.observe(el);
      observers.push(io);
    });

    return () => observers.forEach((o) => o.disconnect());
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 border-b transition-[background-color,box-shadow,border-color] duration-300",
        scrolled
          ? "border-ink/10 bg-paper/92 shadow-[0_12px_40px_-24px_rgba(22,24,20,0.45)] backdrop-blur-md"
          : "border-transparent bg-transparent",
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8">
        <a href="#top" className="flex items-baseline gap-3 no-underline">
          <span className="font-display text-[11px] font-bold tracking-[0.28em] text-sienna uppercase">
            Lineage
          </span>
          <span className="font-mono text-[11px] text-ink-mute">01 / 2026</span>
        </a>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Audit sections">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              aria-current={active === link.href.slice(1) ? "location" : undefined}
              className={cn(
                "px-2.5 py-1.5 font-display text-[11px] font-semibold tracking-[0.14em] uppercase transition-colors",
                active === link.href.slice(1)
                  ? "text-sienna"
                  : "text-ink-soft hover:text-ink",
              )}
            >
              {link.label}
            </a>
          ))}
        </nav>

        <button
          type="button"
          className="inline-flex h-11 w-11 items-center justify-center lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          <span className="sr-only">{open ? "Close" : "Menu"}</span>
          <span className="flex w-5 flex-col gap-1.5">
            <span className={cn("h-px bg-ink transition-transform", open && "translate-y-[4px] rotate-45")} />
            <span className={cn("h-px bg-ink transition-opacity", open && "opacity-0")} />
            <span className={cn("h-px bg-ink transition-transform", open && "-translate-y-[4px] -rotate-45")} />
          </span>
        </button>
      </div>

      {open ? (
        <div id="mobile-nav" className="border-t border-rule bg-paper px-5 py-4 lg:hidden">
          <nav className="flex flex-col" aria-label="Mobile">
            {links.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="border-b border-rule/60 py-3 font-display text-sm tracking-[0.12em] text-ink uppercase"
                onClick={() => setOpen(false)}
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>
      ) : null}
    </header>
  );
}

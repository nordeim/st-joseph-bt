import { dimensions } from "@/data/audit";

export function Scorecard() {
  return (
    <section id="scores" className="border-t border-rule bg-paper-2/40">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 sm:py-28">
        <HeaderBlock
          kicker="01 — Ledger"
          title="Ten dimensions, scored."
          lede="Each score is 1–10. Ties are declared where the CSS contracts are identical. Winners are the site that authored or finished the work, not the one that merely inherited it."
        />

        <div className="mt-4 mb-10 flex flex-wrap gap-6 font-mono text-[11px] tracking-wide text-ink-mute uppercase">
          <span className="inline-flex items-center gap-2">
            <i className="inline-block h-2 w-5 bg-rother" aria-hidden /> Rother
          </span>
          <span className="inline-flex items-center gap-2">
            <i className="inline-block h-2 w-5 bg-joseph" aria-hidden /> St Joseph
          </span>
        </div>

        <ol className="divide-y divide-rule border-y border-rule">
          {dimensions.map((d, i) => (
            <li key={d.id} className="grid gap-6 py-8 lg:grid-cols-12 lg:items-center">
              <div className="lg:col-span-3">
                <p className="font-mono text-[11px] text-ink-mute">
                  {String(i + 1).padStart(2, "0")}
                </p>
                <h3 className="mt-1 font-display text-xl font-bold tracking-tight">
                  {d.label}
                </h3>
                <p
                  className={`mt-2 font-display text-[11px] tracking-[0.16em] uppercase ${
                    d.winner === "tie"
                      ? "text-ink-mute"
                      : d.winner === "rother"
                        ? "text-rother"
                        : "text-joseph"
                  }`}
                >
                  {d.winner === "tie" ? "Tie" : d.winner === "rother" ? "Rother" : "St Joseph"}
                </p>
              </div>

              <div className="space-y-3 lg:col-span-4">
                <Bar label="Rother" value={d.rother} tone="rother" />
                <Bar label="St Joseph" value={d.joseph} tone="joseph" />
              </div>

              <p className="text-[0.98rem] leading-relaxed text-ink-soft lg:col-span-5">
                {d.note}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function Bar({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: "rother" | "joseph";
}) {
  return (
    <div>
      <div className="mb-1.5 flex justify-between font-mono text-[11px] text-ink-mute">
        <span>{label}</span>
        <span>{value.toFixed(1)}</span>
      </div>
      <div className="h-1.5 overflow-hidden bg-paper-3">
        <div
          className={`bar-fill h-full ${tone === "rother" ? "bg-rother" : "bg-joseph"}`}
          style={{ width: `${value * 10}%` }}
        />
      </div>
    </div>
  );
}

export function HeaderBlock({
  kicker,
  title,
  lede,
}: {
  kicker: string;
  title: string;
  lede: string;
}) {
  return (
    <div className="mb-12 max-w-3xl">
      <p className="font-display text-[11px] font-semibold tracking-[0.28em] text-sienna uppercase">
        {kicker}
      </p>
      <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">
        {title}
      </h2>
      <p className="mt-5 text-lg leading-relaxed text-ink-soft">{lede}</p>
    </div>
  );
}

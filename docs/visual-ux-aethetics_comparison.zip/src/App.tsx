import { Architecture } from "@/components/Architecture";
import { Dna } from "@/components/Dna";
import { Findings } from "@/components/Findings";
import { Frames } from "@/components/Frames";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { Motion } from "@/components/Motion";
import { Scorecard } from "@/components/Scorecard";
import { MethodStrip, SiteFooter, Verdict } from "@/components/Verdict";

export default function App() {
  return (
    <>
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <Header />
      <main id="main">
        <Hero />
        <MethodStrip />
        <Scorecard />
        <Dna />
        <Frames />
        <Motion />
        <Architecture />
        <Findings />
        <Verdict />
      </main>
      <SiteFooter />
    </>
  );
}
